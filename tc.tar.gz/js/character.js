/*class Character {
  constructor(name, row, col, race, race_mod, hp) {
    this.name     = name;
    this.row      = row;
    this.col      = col;
    this.race     = race;
    this.race_mod = race_mod;
    this.hp       = hp;
  }
}*/